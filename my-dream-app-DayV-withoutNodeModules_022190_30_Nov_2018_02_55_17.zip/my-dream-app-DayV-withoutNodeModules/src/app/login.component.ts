import { Component } from '@angular/core';
import { LoginService } from './login.service';

@Component({
    selector: 'login',
    template:`
        <!-- <h3>Login Component!</h3>
        Enter UserName:- <input [value]='name'/><br/><br/>
        Enter Password:- <input type='password' [value]='password' /><br/><br/>
        <button>Login</button> -->

        <!-- <h3>Login Component!</h3>
        Enter UserName:- <input [value]='name' (change)='doSomething(uname.value)' #uname/><br/><br/>
        Enter Password:- <input type='password' [value]='password' /><br/><br/>
        <button>Login</button><br/><br/>

        <h1>Name in the template:- {{uname.value}}</h1>
        <h1> Actual Name:-  {{name}} </h1>  -->

        <h3>Login Component!</h3>
        Enter UserName:- <input [(ngModel)]="name" #uname /><br/><br/>
        Enter Password:- <input type="password" [(ngModel)]='password' /><br/><br/>
        <button (click)='doLogin()'>Login</button><br/><br/>

        <h1> Name in the template:- {{uname.value}}</h1>
        <h1> Actual Name:-  {{name}} </h1>
    `
})
export class LoginComponent {
    name:string;
    password:string;
    constructor(private loginService:LoginService) { 
        this.name = 'admin';
        this.password = 'admin';
    }
    doSomething(uname){
        this.name = uname;
        console.log(this.name);        
    }
    doLogin(){        
        this.loginService.setUserName(this.name);
    }

}
