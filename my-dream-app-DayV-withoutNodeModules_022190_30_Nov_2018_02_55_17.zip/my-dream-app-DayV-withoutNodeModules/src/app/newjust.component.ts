import { Component } from '@angular/core';

@Component({
    selector: 'just-newjust',
    template:`
    <div>
        <h1>{{message}}!</h1>
    </div>
    `,
    styles:[`
    div{
        padding:10px;
    }
    h1{
        color:aqua;
        background-color:indigo;
    }
    `]
})
export class NewJustComponent{
    message:string;
    constructor() {
        this.message = "Just to say Hi from Just Module's NewJust Component";
     }
}