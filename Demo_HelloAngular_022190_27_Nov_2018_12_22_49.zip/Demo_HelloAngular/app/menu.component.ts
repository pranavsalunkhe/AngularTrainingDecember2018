import { Component} from '@angular/core';

@Component({
    selector: 'menu',
    templateUrl: 'menu.component.html',
})
export class MenuComponent {
    menuItems:string[];
    constructor() {
        this.menuItems = ['Login','Products','Cart Details', 'Mobiles'];
     }
}