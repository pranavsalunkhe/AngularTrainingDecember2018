var webpack = require('webpack');
var HtmlWebpackPlugin = require('html-webpack-plugin');

const path = require('path');
const rootDir = path.resolve(__dirname);

module.exports = {
    entry: {
        'polyfills':'./polyfills.ts',
        'vendor':'./vendor.ts',
        'app': './app/main.ts',
    },

    resolve: {
        extensions: ['.js', '.ts']
    },

    module:{
        rules:[
            {
                test:/\.ts$/,
                loaders: [
                    {
                        /* awesome-typescript-loader loader was created mostly 
                        to speed-up compilation 
                        *   awesome-typescript-loader (atl) uses dependency resolution 
                            to build modules dependency graph at early stages 
                        *   atl has first-class integration with Babel and enables 
                            caching possibilities. This can be useful for those
                            who use Typescript with Babel.
                        *   atl is able to fork type-checker to a separate process, 
                           which also speeds-up some development scenarios 
                           (e.g. react with react-hot-loader) */
                        loader: 'awesome-typescript-loader',
                        options: { configFileName: './tsconfig.json' }
                    }, 
                    /* This loader allows you to decouple templates from the 
                        component file and maintain AoT compilation. This is 
                        particularly useful when building complex components 
                        that have large templates. */
                    'angular2-template-loader'                    
                ]
            },
            {
                test: /\.html$/,
                loader: 'html-loader'
            },
            {
                test: /\.css$/,
                loader: 'style-loader!css-loader?root=.'
            },
            {
                test: /\.(eot|svg|ttf|woff|woff2)$/,
                loader: 'file-loader?name=public/fonts/[name].[ext]'
            }
        ]
    },
    plugins:[
        
        /*  The CommonsChunkPlugin is an opt-in feature that 
            creates a separate file (known as a chunk), consisting 
            of common modules shared between multiple entry 
            points. By separating common modules from bundles, 
            the resulting chunked file can be loaded once 
            initially, and stored in cache for later use. 
            This results in pagespeed optimizations as the 
            browser can quickly serve the shared code from 
            cache, rather than being forced to load a larger
            bundle whenever a new page is visited. */
        new webpack.optimize.CommonsChunkPlugin({
            name: ['app', 'vendor', 'polyfills']
        }),

        //The HtmlWebpackPlugin simplifies creation of HTML 
        //files to serve your webpack bundles.
        //The plugin will generate an HTML5 file for you
        //that includes all your webpack bundles 
        //in the body using script tags.
        new HtmlWebpackPlugin({
            template: './index.html'
        }),

        //The ContextReplacementPlugin allows you to 
        //override the inferred information. 
        //ContextReplacementPlugin lets you specify the 
        //specific files that webpack should import.
        new webpack.ContextReplacementPlugin(
            /angular(\\|\/)core(\\|\/)@angular/,
            path.resolve(__dirname)
        ),
        new webpack.ProvidePlugin({
            $: 'jquery',
            jQuery: 'jquery',
            "window.jQuery": 'jquery'            
        })
    ]
};