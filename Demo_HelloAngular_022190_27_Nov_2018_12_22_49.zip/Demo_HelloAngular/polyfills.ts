/* This file includes polyfills needed by Angular 
and is loaded before the app.
This file is divided into 2 sections:
 *   1. Browser polyfills. These are applied before 
       loading ZoneJS and are sorted by browsers.
 *   2. Application imports. Files imported after 
        ZoneJS that should be loaded before your main file.
*/

import 'core-js/es6';
/* Evergreen browsers require these. 
 Used for reflect-metadata in JIT. If you use AOT
 (and only Angular decorators), you can remove.
*/
import 'core-js/es7/reflect';

/*Zone JS is required by default for Angular itself. */
import 'zone.js/dist/zone';

if (process.env.ENV === 'production') {
}
else {
    Error['stackTraceLimit'] = Infinity;
    require('zone.js/dist/long-stack-trace-zone');
}