// Angular

import '@angular/common'
import '@angular/core'
import '@angular/platform-browser'
import '@angular/platform-browser-dynamic'

import 'rxjs'

// other vendors

import 'jquery'
import 'bootstrap/dist/js/bootstrap'
import 'bootstrap/dist/css/bootstrap.css'