// import { Component } from '@angular/core';
// import { Observable } from 'rxjs';
// import 'rxjs/add/observable/interval';
// import 'rxjs/add/operator/take';
// import 'rxjs/add/operator/map';

// @Component({
//     selector: 'asyncpipe',
//     template:`
//         <div class='card card-block'>
//         <h2>Async Pipe Demo</h2>
//         <p class='card-text' ngNonBindable>{{ observableData }}</p>
//         <p class='card-text'>{{observableData}}</p>
//         </div>
//     `
    
// })
// export class ObersvableDataComponent{
//     observableData: number;
//     subscription:any = null;
//     constructor() { 
//         this.subscribeObservable();
//     }
//     getObservable(){
//         return Observable.
//         interval(1000)
//         .take(10)
//         .map(v => v*v);

//     }
//     subscribeObservable(){
//         this.subscription = this.getObservable()
//         .subscribe(v => this.observableData = v);
//     }

//     ngDestroy(){
//         if(this.subscription)
//             {
//                 this.subscription.unsubscribe();
//             }
//     }
// }

import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import 'rxjs/add/observable/interval';
import 'rxjs/add/operator/take';
import 'rxjs/add/operator/map';

@Component({
    selector: 'asyncpipe',
    template:`
        <div class='card card-block'>
        <h2>Async Pipe Demo</h2>
        <p class='card-text' ngNonBindable>{{ observable }}</p>
        <p class='card-text'>{{observable | async}}</p>
        </div>
    `
})
export class ObersvableDataComponent{
    observable: Observable<number>

    constructor() { 
    this.observable = this.getObservable();
    }
    getObservable(){
        return Observable.
        interval(1000)
        .take(10)
        .map(v => v*v);
    }
}
