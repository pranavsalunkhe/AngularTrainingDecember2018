import { Injectable } from '@angular/core';

@Injectable()
export class MenuService {
    private menuItems:string[];
    constructor() { 
        // these menu items could be taken from the server
        this.menuItems = [
            "Login","Products","CartDetails","Photos"
        ]
    }
    getItems():string[]{
        return this.menuItems;
    }

}