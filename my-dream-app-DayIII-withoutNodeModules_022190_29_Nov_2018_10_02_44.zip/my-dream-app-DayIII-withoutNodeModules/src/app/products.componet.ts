import { Component } from '@angular/core';
import { Product } from './product';
import { ProductsService } from './products.service';

@Component({
    selector: 'products',
    template: `
        <div>
           <!-- Enter Search:- <input type='text'
            (blur)='doSearch($event.target.value)' /><br/><br/> -->

            <!-- # template ref var-->
            Enter Search:- <input type='text' #search
            (blur)='doSearch(search.value)' /><br/><br/>
            
            <greet #myGreet></greet>
            <h1>{{myGreet.name}}</h1>            
        </div>
        <table border='3ps solid black' align="center">
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Price</th>
                <th>Product Image</th>
                <th colspan='2'>Actions</th>
            <tr>
            <tr *ngFor="let product of products, let i=index">
                <td>{{product.id}}</td>
                <td><a href="{{product.id}}">{{product.name}}</a></td>
                <td>{{product.price}} /-</td>               
                <!-- <td><img src="{{product.imgPath}}" /></td> -->
                <!-- Property Binding -->
                <!-- <td><img [src]="product.imgPath" /></td> -->
                <td><img bind-src="product.imgPath" /></td>
                <td><button [disabled]='!isAdmin'>Edit</button></td>
                <td><button *ngIf='isAdmin' (click)='showDetails(product)'>Details</button></td>
            </tr>
        </table>
    `,
    styles: [`
    img{
        width:auto;
        height:100px;
    }
    table{
        display: 'inline-block';
        float: left;
        margin-left: 50px;
      }
        table caption{
        text-align: center;
      }       
        th{
        text-align: center;
        background-color: peachpuff;
        fontWeight: bold;
      }
      `],
    providers: [ProductsService]
})
export class ProductsComponent {
    products: Array<Product>
    isAdmin:boolean;
    constructor(productsService: ProductsService) {
        this.isAdmin = true;
        this.products = productsService.getProducts();
    }
    showDetails(product){
        alert(product.category+' '+product.name+' Rs '+product.price);
    }
    doSearch(searchStr:string){
        var prodNames:string [] = [];
        for(var i in this.products){
            if(this.products[i].name.toLowerCase()
            .startsWith(searchStr.toLowerCase())){
                prodNames.push(this.products[i].name);
            }
        }
        alert(prodNames);
    }
}
