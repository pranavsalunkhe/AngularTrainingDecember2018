import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { GreetComponent } from './greet/greet.component';
import { AppIIComponent } from './appII.component';
import { JustModule } from './just.module';
import { MenuComponent } from './menu.component';
import { ProductsComponent } from './products.componet';
import { LoginComponent } from './login.component';

@NgModule({
  declarations: [
    AppComponent,
    GreetComponent,
    //AppIIComponent,
    MenuComponent,
    ProductsComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    JustModule,
    FormsModule
  ],
  providers: [],
  // bootstrap: [AppComponent, AppIIComponent]
  bootstrap: [AppComponent]
})
export class AppModule { }
