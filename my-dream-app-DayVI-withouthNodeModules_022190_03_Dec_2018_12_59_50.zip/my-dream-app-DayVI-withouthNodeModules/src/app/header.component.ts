import { Component} from '@angular/core';
import { LoginService } from './login.service';
import { SessionStorage } from 'angular-web-storage';

@Component({
    selector: 'app-header',    
    template:`    
    <h2>Welcome {{userName}}!</h2>
    `
})
export class HeaderComponent{

    @SessionStorage()
    userName:string;

    constructor(private loginService:LoginService) {         
        loginService.getUserName().subscribe(newName => {
            this.userName = newName;
        })
    }
}
