import { Component} from '@angular/core';
import { MenuService } from './menu.service';

@Component({
    selector: 'menu',
    templateUrl: 'menu.component.html',
    providers:[MenuService] // registering MenuService with Angular DI at component level
})
export class MenuComponent {
    menuItems:string[];
    // constructor() {
    //     this.menuItems = ['Login','Products','Cart Details', 'Mobiles'];
    //  }
    constructor(menuService:MenuService) { // Injecting the Service
      this.menuItems = menuService.getItems();
     }
}