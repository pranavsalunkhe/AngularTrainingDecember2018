import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AngularWebStorageModule } from 'angular-web-storage';
import {RouterModule, Routes} from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { GreetComponent } from './greet/greet.component';
import { AppIIComponent } from './appII.component';
import { JustModule } from './just.module';
import { MenuComponent } from './menu.component';
import { ProductsComponent } from './products.componet';
import { LoginComponent } from './login.component';
import { AddToCartComponent } from './addtocart.component';
import { CartDetailsComponent } from './cartdetails.component';
import { HeaderComponent } from './header.component';
import { LoginService } from './login.service';
import { ProfileComponent } from './profile.component';
import { PageNotFoundComponent } from './pagenotfound.component';
import { ProductDetailsComponent } from './productdetails.component';
import { PhotosComponent } from './photos.component';
import { SignUpFormComponent } from './signupform.component';
import { ReactiveformComponent } from './reactiveform/reactiveform.component';

let routes:Routes = [
    {
      path:'', // default path
      redirectTo:'greet',
      pathMatch:'full'
    },
    {
      path:'greet',
      component:GreetComponent
    },
    {
      path:'login',
      component:LoginComponent
    },
    {
      path:'products',
      component:ProductsComponent,
      children:[{
        path:'productdetails/:id',
        component:ProductDetailsComponent
      }]
    },
    {
      path:'cartdetails',
      component:CartDetailsComponent
    },
    {
      path:'profile',
      component:ProfileComponent
    },
    {
      path:'photos',
      component:PhotosComponent
    },
    {
      path:'signup',
      component:SignUpFormComponent
    },
    {
      path:'reactiveform',
      component:ReactiveformComponent
    },
    {
      path:'**',
      component:PageNotFoundComponent
    }
]

@NgModule({
  declarations: [
    AppComponent,
    GreetComponent,
    //AppIIComponent,
    MenuComponent,
    ProductsComponent,
    LoginComponent,
    AddToCartComponent,
    CartDetailsComponent,
    HeaderComponent,
    ProfileComponent,
    PageNotFoundComponent,
    ProductDetailsComponent,
    PhotosComponent,
    SignUpFormComponent,
    ReactiveformComponent
  ],
  imports: [
    BrowserModule,
    JustModule,
    FormsModule,
    AngularWebStorageModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [LoginService],
  // bootstrap: [AppComponent, AppIIComponent]
  bootstrap: [AppComponent]
})
export class AppModule { }
