import { Component, Input, EventEmitter, Output } from '@angular/core';

@Component({
    selector: 'app-profile',
    template:`
        <h1> Profile Component </h1>
        <input type='text' [(ngModel)]='profileName' /><br/><br/>
        <button (click)="updateName()">Update Parent!</button><br/><br/>
        <h2>Profile Name:- {{profileName}}!</h2>

    `
})
export class ProfileComponent{

    @Input()
    profileName:string;

    @Output()
    update:EventEmitter<string> = new EventEmitter<string>();

    constructor() { 
        this.profileName = 'Abhijeet';
    }

    updateName(){
        // raising the update event of ProfileComponent
        this.update.emit(this.profileName);
    }
}
