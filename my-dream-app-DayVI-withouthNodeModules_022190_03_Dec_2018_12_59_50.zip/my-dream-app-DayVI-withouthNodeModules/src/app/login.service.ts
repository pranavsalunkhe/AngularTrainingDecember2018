import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable()
export class LoginService {
    subj:Subject<string> = new Subject<string>();

    setUserName(userName:string){
        this.subj.next(userName); // notify to the subscribers
    }

    getUserName():Observable<string>{
        return this.subj.asObservable();
    }
}