import { Component } from '@angular/core';

@Component({
    selector: 'signupform',
    templateUrl: './signupform.component.html',
    styleUrls: ['./signupform.component.css']
})
export class SignUpFormComponent{

        user = {
            name:'Sachin',
            phone:9876543210,
            address:'India',
            email:'Sachin@cricket.com'
        }
    constructor() { }

    postForm(){
        alert('Form Submitted!');
    }
}
