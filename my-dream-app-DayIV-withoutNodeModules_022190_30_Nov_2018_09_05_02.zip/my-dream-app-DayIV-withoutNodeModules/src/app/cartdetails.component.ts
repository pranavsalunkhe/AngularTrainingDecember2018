import { Component } from '@angular/core';
import { Product } from './product';
import { CartService } from '../cart.service';

@Component({
    selector: 'cartdetails',    
    template:`
        <h1>My Cart Products</h1>
        <table border='3px solid black' align='center'>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Price</th>
                <th>Product Image</th>
                <th>Category</th>
                <th>Action</th>
            </tr>
            <tr *ngFor="let product of cartProducts; let i=index;">
                <td>{{product.id}}</td>
                <td>{{product.name}}</td>
                <td>{{product.price}}</td>
                <td><img [src]="product.imgPath" /></td>
                <td>{{product.category}}</td>
                <td><button>Delete</button></td>             
            </tr>
        </table>`,
    styles: [`
    img{
        width:auto;
        height:130px;
    }
    th{
        text-align:center;
        background-color:peachpuff;
        fontWeight:bold;
    }
    `],
    //providers:[CartService]
})
export class CartDetailsComponent{
    cartProducts:Product[];    
    cartService:CartService;
    constructor(cartService:CartService) {
        this.cartService = cartService;
        this.cartService.cartBroadCaster.subscribe(
            res => {
                this.cartProducts = JSON.parse(res);
            })

        this.cartProducts = this.cartService.getCartItems();
     }
}
