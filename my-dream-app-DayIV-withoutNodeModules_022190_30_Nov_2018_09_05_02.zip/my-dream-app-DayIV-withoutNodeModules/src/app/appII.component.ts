import { Component } from '@angular/core';

@Component({
    selector: 'appII',
    template:`
            <div>
                <h1>Welcome to  {{title}}</h1>
            </div>
    `,
    styles:[`
        h1{
            color:yellow;
            background:green;
        }
        div{
            text-align:center;
        }
    `]
})
export class AppIIComponent{
    title:string;
    constructor() { 
        this.title = "Angular Component II";
    }
}