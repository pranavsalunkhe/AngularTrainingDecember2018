import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NewJustComponent } from './newjust.component';

@NgModule({
    imports: [ BrowserModule ],
    declarations: [ NewJustComponent ],
    exports:[NewJustComponent]
})
export class JustModule { }