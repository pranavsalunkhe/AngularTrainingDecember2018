import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AngularWebStorageModule } from 'angular-web-storage';

import { AppComponent } from './app.component';
import { GreetComponent } from './greet/greet.component';
import { AppIIComponent } from './appII.component';
import { JustModule } from './just.module';
import { MenuComponent } from './menu.component';
import { ProductsComponent } from './products.componet';
import { LoginComponent } from './login.component';
import { AddToCartComponent } from './addtocart.component';
import { CartDetailsComponent } from './cartdetails.component';

@NgModule({
  declarations: [
    AppComponent,
    GreetComponent,
    //AppIIComponent,
    MenuComponent,
    ProductsComponent,
    LoginComponent,
    AddToCartComponent,
    CartDetailsComponent
  ],
  imports: [
    BrowserModule,
    JustModule,
    FormsModule,
    AngularWebStorageModule
  ],
  providers: [],
  // bootstrap: [AppComponent, AppIIComponent]
  bootstrap: [AppComponent]
})
export class AppModule { }
