import { Component } from '@angular/core';

@Component({
  selector: 'greet',
  templateUrl: './greet.component.html',
  styleUrls: ['./greet.component.css']
})
export class GreetComponent {
  name: string;
  isDisabled:boolean;
  constructor() {
    this.name = 'Sachin';
    this.isDisabled = false;
  }
}
