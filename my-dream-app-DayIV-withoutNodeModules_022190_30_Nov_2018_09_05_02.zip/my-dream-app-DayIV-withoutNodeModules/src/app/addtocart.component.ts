import { Component, Input } from '@angular/core';
import { Product } from './product';
import { CartService } from '../cart.service';

@Component({
    selector: 'addtocart',
    template:`
    <button (click)='addProduct()'>Add To Cart!</button>
    `,
    //providers:[CartService]
})
export class AddToCartComponent{

    @Input()
    selectedProduct:Product;

    constructor(private cartService:CartService) { }
    addProduct(){
        alert(this.selectedProduct.name);
        this.cartService.addProduct(this.selectedProduct);
    }
}
